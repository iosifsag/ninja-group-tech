# Ninja Group Of Tech 
It is a website developed using HTML, Javascript and Java. It runs on Apache Tomcat and PostgreSQL.
